prompt("Ismingizni kiriting")
prompt("Familiyangizni kiriting")
prompt("yoshingizni kiriting")
let a = "azizek"
let b = prompt("Ismingizni kiriting")
let c= prompt("Familiyangizni kiriting")
let d = prompt("yoshingizni kiriting")
alert("malumot uchun rahmat")
console.log(a);
console.log(b);
console.log(c);
console.log(d);